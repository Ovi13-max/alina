<?php include("includes/head.php");?>
<?php include("includes/suma_total_content.php"); ?>
<?php include("includes/footer.php");?>