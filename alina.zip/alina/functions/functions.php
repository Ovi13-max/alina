<?php

//start_iframe_link_css

function iframe_link_css() {
    echo "<link rel='stylesheet' type='text/css' media='all' href='../../style/content.css' />";
}

function list_content_link_css() {
    echo "<link rel='stylesheet' type='text/css' media='all' href='../../style/list_content.css' />";
}

function suma_total_content_link_css() {
    echo "<link rel='stylesheet' type='text/css' media='all' href='../../style/suma_total_content.css' />";
}

function main_css() {
    echo "<link rel='stylesheet' type='text/css' media='all' href='style/main_style.css' />";
}

//finish_iframe_link_css

function fill_the_fields() {
    echo "<link rel='stylesheet' type='text/css' media='all' href='../../../style/list_content.css' />";
    echo "<center>
            <div id='result_text'>
                <span>
                    Te rog să complectezi toate casuțele !!!<br>
                    Ne întoarcem la pagina principală in 1 sec!!!<br>
                    Îți mulțumesc !!!
                </span>
            </div>
       </center>";
    $back = "refresh: 1; url=../content_frame.php";
    header($back);
}


function fields_are_fill() {
    echo "<link rel='stylesheet' type='text/css' media='all' href='../../../style/list_content.css' />";
    echo "<center>
            <div id='result_text'>
               <span> Operațiunea a avut succes !!! <br>Ne întoarcem la pagina principală in 1 sec !!!<br>
                      Îți mulțumesc !!!
               </span>
            </div>
           </center>";
    $back = "refresh: 1; url=../content_frame.php";
    header($back);
}

//-------------------------------------------------------------------------------------------

?>