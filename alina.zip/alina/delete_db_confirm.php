<?php require_once("includes/db_conn.php");?>
<?php require_once("functions/functions.php");?>
<?php echo main_css();?>
<?php

if (isset($conn)) {
    $query = "DELETE FROM vinzari WHERE created_at < now()";
    $conn->query($query);
    mysqli_query($conn,"ALTER TABLE vinzari AUTO_INCREMENT = 1");
    echo "<p class='delete_db_confirm'>
            Baza de date a fost stearsa !!!<br>Baza de date sa pornit de la 1!!!
          </p>";
    header("refresh:1, index.php");
}
else {
    echo "<p class='delete_db_confirm'>
            Baza de date nu a fost stearsa !!!
          </p>";
    header("refresh:0.5, index.php");
}

?>