-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 31, 2023 at 06:28 AM
-- Server version: 8.0.32
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quizmast_alina`
--

-- --------------------------------------------------------

--
-- Table structure for table `vinzari`
--

CREATE TABLE `vinzari` (
  `id` int NOT NULL,
  `nume_produs` varchar(25) NOT NULL,
  `cantitate` varchar(25) NOT NULL,
  `pret` varchar(25) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vinzari`
--

INSERT INTO `vinzari` (`id`, `nume_produs`, `cantitate`, `pret`, `created_at`) VALUES
(1, 'lichid_fresh', '2', '68', '2023-03-30 20:14:56'),
(2, 'lichid_mare_0_nic', '1', '36', '2023-03-30 20:15:10'),
(3, 'lichid_fresh', '1', '34', '2023-03-30 20:15:20'),
(4, 'lichid_vpg_10_mg', '1', '25', '2023-03-30 20:15:29'),
(5, 'lichid_fresh', '2', '68', '2023-03-30 20:15:41'),
(6, 'lichid_vg', '1', '40', '2023-03-30 20:15:53'),
(7, 'lichid_fresh', '1', '34', '2023-03-30 20:16:03'),
(8, 'lichid_vpg_10_mg', '2', '50', '2023-03-30 20:16:18'),
(9, 'lichid_mare_0_nic', '1', '36', '2023-03-30 20:16:30'),
(10, 'lichid_fresh', '1', '34', '2023-03-30 20:16:42'),
(11, 'lichid_mare_0_nic', '1', '36', '2023-03-30 20:16:51'),
(12, 'lichid_vpg_10_mg', '1', '25', '2023-03-30 20:17:07'),
(13, 'cartomizor_logic', '1', '18', '2023-03-30 20:17:21'),
(14, 'lichid_fresh', '1', '34', '2023-03-30 20:17:31'),
(15, 'lichid_vpg_10_mg', '1', '25', '2023-03-30 20:17:48'),
(16, 'lichid_fresh', '1', '34', '2023-03-30 20:17:58'),
(17, 'lichid_vpg_10_mg', '1', '25', '2023-03-30 20:18:08'),
(18, 'lichid_fresh', '1', '34', '2023-03-30 20:18:25'),
(19, 'lichid_vpg_10_mg', '4', '100', '2023-03-30 20:18:40'),
(20, 'lichid_vpg_10_mg', '1', '25', '2023-03-30 20:18:56'),
(21, 'lichid_vg', '1', '40', '2023-03-30 20:19:09'),
(22, 'lichid_mare_0_nic', '3', '108', '2023-03-30 20:19:28'),
(23, 'atomizor_mic', '2', '56', '2023-03-30 20:19:53'),
(24, 'kit_ego', '1', '129', '2023-03-30 20:20:13'),
(25, 'lichid_vpg_10_mg', '2', '50', '2023-03-30 20:20:25'),
(26, 'lichid_fresh', '1', '34', '2023-03-30 20:20:36'),
(27, 'lichid_vpg_10_mg', '2', '50', '2023-03-30 20:20:59'),
(28, 'lichid_fresh', '1', '34', '2023-03-30 20:21:10'),
(29, 'lichid_fresh', '2', '68', '2023-03-30 20:21:19'),
(30, 'lichid_fresh', '1', '34', '2023-03-30 20:21:35'),
(31, 'lichid_mare_0_nic', '1', '36', '2023-03-30 20:21:49'),
(32, 'baterie_tank_t_cbd', '1', '68', '2023-03-30 20:22:10'),
(33, 'cartomizor_logic', '2', '36', '2023-03-30 20:22:36'),
(34, 'lichid_mare_0_nic', '1', '36', '2023-03-30 20:22:48'),
(35, 'lichid_baza', '1', '16', '2023-03-30 20:23:00'),
(36, 'lichid_fresh', '1', '34', '2023-03-30 20:24:35'),
(37, 'lichid_mare_0_nic', '1', '36', '2023-03-30 21:15:35'),
(38, 'lichid_baza', '1', '16', '2023-03-30 21:15:46'),
(39, 'lichid_fresh', '1', '34', '2023-03-30 21:24:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `vinzari`
--
ALTER TABLE `vinzari`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vinzari`
--
ALTER TABLE `vinzari`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
