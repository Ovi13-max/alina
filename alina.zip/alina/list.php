<?php include("includes/head.php");?>
<?php include("includes/list_content.php"); ?>
<?php include("includes/footer.php");?>