<?php require_once("includes/db_conn.php");?>
<?php require_once("functions/functions.php");?>
<?php echo main_css();?>
<div class="delete_db">
    <p>ESTI SIGUR CA VREI SA STERGI BAZA DE DATE !!!!</p><br>
    <p><a href= "delete_db_confirm.php">Sterge baza de date !!!</a></p>
</div>
