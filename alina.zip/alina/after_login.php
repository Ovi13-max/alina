<!-- Copyright (C) OvidiuBara, ovidiubara Proprietary Use License (http://www.webdesign-pro.ro/license/)-->
<?php include("includes/head.php");?>
<?php include("includes/content.php"); ?>
<?php include("includes/footer.php");?>