<?php require_once("../../../functions/functions.php");?>
<?php require_once("../../../includes/db_conn.php");?>
<?php include("../../../includes/preturi.php");?>
<?php

$nume_produs = array('lichid_vg_10_mg', 'lichid_vpg_0_nic', 'lichid_vpg_10_mg', 'lichid_mix', 'lichid_special', 'lichid_fresh', 'lichid_mare_0_nic',
                     'lichid_mix_of_go', 'lichid_vg', 'lichid_baza', 'cartomizor_mod', 'kit_ego_simplu', 'kit_ego', 'kit_ego_tank', 'kit_new_ego',
                     'kit_mod_mecanic', 'kit_starter', 'kit_mod', 'kit_unic', 'sipca_tank', 'atomizor_mic', 'baterie_mod', 'baterie_tutun_naghilea',
                     'baterie_tank_t_cbd', 'minerale_naghilea', 'carbune_naghilea', 'carbune_cocos', 'naghilea_medie', 'naghilea_mare', 'cartomizor_logic',
                     'accesorii', 'incarcator_usb', 'tub_tigara_p_zipo', 'baterie_pass');

$cantitate_produs32 = $_POST['incarcator_usb_cantitate'];
$pret_produs32 = $incarcator_usb*$cantitate_produs32;

if(empty($_POST['incarcator_usb_cantitate']))
{
    fill_the_fields();
}

else {
    $sql = "INSERT INTO  vinzari (nume_produs, cantitate, pret) VALUES ('$nume_produs[31]', '$cantitate_produs32', '$pret_produs32')";
        if ($conn->query($sql) === TRUE) {
            fields_are_fill();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }

        $conn->close();
}

?>