<?php require_once("functions/functions.php");?>
<?php echo list_content_link_css();?>
<?php
echo "<div class= 'left'>";
echo "<ul>";
    echo "<li>";
            $sql = "SELECT nume_produs, sum(cantitate), sum(pret) FROM vinzari WHERE nume_produs = 'baterie_tutun_naghilea' GROUP BY nume_produs ORDER BY nume_produs";
            $result = mysqli_query($conn, $sql);
            $num_results = mysqli_num_rows($result);
            if (mysqli_num_rows($result) > 0) {
                //output data of each row
                 while($row = mysqli_fetch_assoc($result)) {
            echo ' 23.' . '  ' . '<span>' .
                $row['nume_produs'] . '</span>' . ' , ' . 'cantitate -' . '  ' . '<span>' .
                $row['sum(cantitate)'] . '</span>' . '   ' . ' , ' . 'pret total -' . '  ' . '<span>' .
                $row['sum(pret)'] . '</span>';
    echo "</li>";
            }
            }
echo "</ul>";
echo "<br>";
echo "</div>";

/*----- put data on file -----*/
$sql = "SELECT nume_produs, sum(cantitate), sum(pret) FROM vinzari WHERE nume_produs = 'baterie_tutun_naghilea' GROUP BY nume_produs ORDER BY nume_produs";
    $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            //output data of each row
            while($row = mysqli_fetch_assoc($result)) {
                $list = array($row['nume_produs'], $row['sum(cantitate)'], $row['sum(pret)']);
                $nume_produs = $list[0];
                $cantitate = $list[1];
                $pret = $list[2];

$time = date('l jS \of F Y h:i:s A', strtotime('+2 hour'));
file_put_contents('data_result/baterie_tutun_naghilea.txt', 'Time' . ' - ' .
                    $time . ',' . ' ' .
                    $nume_produs . ',' . ' ' . 'Cantitate' . ' - ' .
                    $list[1] . ',' . ' ' . 'Pret' . ' - ' .
                    $list[2] . PHP_EOL, FILE_APPEND | LOCK_EX);
}
}
?>