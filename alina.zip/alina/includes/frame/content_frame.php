<?php require_once("../../functions/functions.php");?>
<?php echo iframe_link_css();?>
<div id="content_frame">
    <table id="vinzari">
            <tr class="title">
                <td class="title_product"><em>Produs</em></td>
                <td><em>Cantitatea</em></td>
                <!--<td>Preț</td>-->
                <td></td>
                <td></td>
            </tr>
        <tr>
            <form enctype="multipart/form-data" method="POST" action="result/submit_1.php">
                <td class="product">1.Lichid VG 10mg</td>
                <td><input id="vinzari_input" type="number" name="lichid_vg_10_mg_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="lichid_vg_10_mg_pret" /></td>-->
                <td><input type="reset" id="button" name="reset_1" value="Reset" /></td>
                <td><input type="submit" id="button" name="submit_1" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_2.php">
                <td class="product">2.Lichid VPG 0 - NIC</td>
                <td><input id="vinzari_input" type="number" name="lichid_vpg_0_nic_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="lichid_vpg_0_nic_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_2" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_2" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_3.php">
                <td class="product">3.Lichid VPG 10mg</td>
                <td><input id="vinzari_input" type="number" name="lichid_vpg_10_mg_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="lichid_vpg_10_mg_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_3" value="Reset"/></td>
                <td class="button"><input type="submit" id="button" name="submit_3" value="Save" /></td>
             </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_4.php">
                <td class="product">4.Lichid Mix</td>
                <td><input id="vinzari_input" type="number" name="lichid_mix_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="lichid_mix_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_4" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_4" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_5.php">
                <td class="product">5.Lichid Special + VA</td>
                <td><input id="vinzari_input" type="number" name="lichid_special_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="lichid_special_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_5" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_5" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_6.php">
                <td class="product">6.Lichid Fresh</td>
                <td><input id="vinzari_input" type="number" name="lichid_fresh_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="lichid_fresh_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_6" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_6" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_7.php">
                <td class="product">7.Lichid Mare 0 - NIC</td>
                <td><input id="vinzari_input" type="number" name="lichid_mare_0_nic_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="lichid_mare_0_nic_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_7" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_7" value="Save" /></td>
             </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_8.php">
                <td class="product">8.Lichid Mix of GO</td>
                <td><input id="vinzari_input" type="number" name="lichid_mix_of_go_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="lichid_mix_of_go_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_8" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_8" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_9.php">
                <td class="product">9.Lichid VG</td>
                <td><input id="vinzari_input" type="number" name="lichid_vg_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="lichid_vg_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_9" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_9" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_10.php">
                <td class="product">10.Lichid Baza</td>
                <td><input id="vinzari_input" type="number" name="lichid_baza_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="lichid_baza_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_10" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_10" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_11.php">
                <td class="product">11.Cartomizor Mod</td>
                <td><input id="vinzari_input" type="number" name="cartomizor_mod_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="cartomizor_mod_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_11" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_11" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_12.php">
                <td class="product">12.Kit EGO Simplu</td>
                <td><input id="vinzari_input" type="number" name="kit_ego_simplu_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="kit_ego_simplu_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_12" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_12" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_13.php">
                <td class="product">13.Kit EGO</td>
                <td><input id="vinzari_input" type="number" name="kit_ego_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="kit_ego_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_13" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_13" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_14.php">
                <td class="product">14.Kit EGO Tank</td>
                <td><input id="vinzari_input" type="number" name="kit_ego_tank_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="kit_ego_tank_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_14" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_14" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_15.php">
                <td class="product">15.Kit NEW EGO</td>
                <td><input id="vinzari_input" type="number" name="kit_new_ego_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="kit_new_ego_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_15" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_15" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_16.php">
                <td class="product">16.Kit Mod Mecanic</td>
                <td><input id="vinzari_input" type="number" name="kit_mod_mecanic_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="kit_mod_mecanic_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_16" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_16" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_17.php">
                <td class="product">17.Kit Starter</td>
                <td><input id="vinzari_input" type="number" name="kit_starter_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="kit_starter_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_17" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_17" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_18.php">
                <td class="product">18.Kit Mod</td>
                <td><input id="vinzari_input" type="number" name="kit_mod_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="kit_mod_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_18" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_18" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_19.php">
                <td class="product">19.Kit Unic</td>
                <td><input id="vinzari_input" type="number" name="kit_unic_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="kit_unic_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_19" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_19" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_20.php">
                <td class="product">20.Sipca Tank</td>
                <td><input id="vinzari_input" type="number" name="sipca_tank_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="sipca_tank_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_20" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_20" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_21.php">
                <td class="product">21.Atomizor Mic</td>
                <td><input id="vinzari_input" type="number" name="atomizor_mic_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="atomizor_mic_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_21" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_21" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_22.php">
                <td class="product">22.Baterie Mod</td>
                <td><input id="vinzari_input" type="number" name="baterie_mod_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="baterie_mod_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_22" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_22" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_23.php">
                <td class="product">23.Bat Tutun Naghilea</td>
                <td><input id="vinzari_input" type="number" name="baterie_tutun_naghilea_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="baterie_tutun_naghilea_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_23" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_23" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_24.php">
                <td class="product">24.Baterie Tank T CBD</td>
                <td><input id="vinzari_input" type="number" name="baterie_tank_t_cbd_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="baterie_tank_t_cbd_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_24" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_24" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_25.php">
                <td class="product">25.Minerale Naghilea</td>
                <td><input id="vinzari_input" type="number" name="minerale_naghilea_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="minerale_naghilea_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_25" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_25" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_26.php">
                <td class="product">26.Carbune Naghilea</td>
                <td><input id="vinzari_input" type="number" name="carbune_naghilea_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="carbune_naghilea_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_26" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_26" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_27.php">
                <td class="product">27.Carbune Cocos</td>
                <td><input id="vinzari_input" type="number" name="carbune_cocos_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="carbune_cocos_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_27" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_27" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_28.php">
                <td class="product">28.Naghilea Medie</td>
                <td><input id="vinzari_input" type="number" name="naghilea_medie_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="naghilea_medie_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_28" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_28" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_29.php">
                <td class="product">29.Naghilea Mare</td>
                <td><input id="vinzari_input" type="number" name="naghilea_mare_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="naghilea_mare_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_29" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_29" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_30.php">
                <td class="product">30.Cartomizor Logic</td>
                <td><input id="vinzari_input" type="number" name="cartomizor_logic_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="cartomizor_logic_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_30" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_30" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_31.php">
                <td class="product">31.Accesorii</td>
                <td><input id="vinzari_input" type="number" name="accesorii_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="accesorii_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_31" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_31" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_32.php">
                <td class="product">32.Incarcator USB</td>
                <td><input id="vinzari_input" type="number" name="incarcator_usb_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="incarcator_usb_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_32" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_32" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_33.php">
                <td class="product">33.Tub Tigara P Zipo</td>
                <td><input id="vinzari_input" type="number" name="tub_tigara_p_zipo_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="tub_tigara_p_zipo_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_33" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_33" value="Save" /></td>
            </form>
        </tr>
        <tr>
            <form id= "form" enctype="multipart/form-data" method="POST" action="result/submit_34.php">
                <td class="product">34.Baterie Pass</td>
                <td><input id="vinzari_input" type="number" name="baterie_pass_cantitate" /></td>
                <!--<td><input id="vinzari_input" type="number" name="baterie_pass_pret" /></td>-->
                <td class="button"><input type="reset" id="button" name="reset_34" value="Reset" /></td>
                <td class="button"><input type="submit" id="button" name="submit_34" value="Save" /></td>
            </form>
        </tr>
    </table>
</div>