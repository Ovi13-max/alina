<?php

    $lichid_vg_10_mg = 56;
    $lichid_vpg_0_nic = 17;
    $lichid_vpg_10_mg = 28;
    $lichid_mix = 45;
    $lichid_special = 18;
    $lichid_fresh = 34;
    $lichid_mare_0_nic = 36;
    $lichid_mix_of_go = 50;
    $lichid_vg = 40;
    $lichid_baza = 18;
    $cartomizor_mod = 15;
    $kit_ego_simplu = 99;
    $kit_ego = 129;
    $kit_ego_tank = 159;
    $kit_new_ego = 179;
    $kit_mod_mecanic = 210;
    $kit_starter = 249;
    $kit_mod = 285;
    $kit_unic = 25;
    $sipca_tank = 6;
    $atomizor_mic = 28;
    $baterie_mod = 49;
    $baterie_tutun_naghilea = 58;
    $baterie_tank_t_cbd = 68;
    $minerale_naghilea = 24;
    $carbune_naghilea = 15;
    $carbune_cocos = 40;
    $naghilea_medie = 145;
    $naghilea_mare = 245;
    $cartomizor_logic = 18;
    $accesorii = 14;
    $incarcator_usb = 22;
    $tub_tigara_p_zipo = 8;
    $baterie_pass = 78;

?>