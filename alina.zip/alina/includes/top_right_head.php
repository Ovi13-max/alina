<div id="top_head_right">
<?php
	$day = date('l');
	$month = date('d'.'/'.'m');
	$year = date('Y');
?>
<ul>
	<li><?php echo $year;?></li>
	<li><?php echo $month;?>/</li>
	<li><?php echo $day;?>&nbsp;</li>
	<li>&nbsp;</li>
	<li><div id="txt"></div></li>
</ul>
<script>
	function startTime()
		{
			var today=new Date();
			var h=today.getHours();
			var m=today.getMinutes();
			var s=today.getSeconds();
				// add a zero in front of numbers<10
				m=checkTime(m);
				s=checkTime(s);
				document.getElementById('txt').innerHTML=h+":"+m+":"+s;
				t=setTimeout(function(){startTime()},500);
		}
	function checkTime(i)
		{
			if (i<10)
  		{
  			i="0" + i;
 		}
	return i;
		}
</script>
</div>