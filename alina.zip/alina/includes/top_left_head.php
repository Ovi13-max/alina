<?php
// Initialize the session
session_start();

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: http://localhost/alina/after_login.php");
    exit;
}
?>

<div id="top_head_left">
    <span>Hello, <?php echo htmlspecialchars($_SESSION["username"]); ?> ! Bine ai venit pe aplicație !</span>
</div>
