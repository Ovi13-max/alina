    <div id="footer">
        <a href="index.php">ACASĂ</a>&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="suma_total.php">SUMA-TOTALĂ</a>&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="list.php">LISTĂ</a>
    </div>
</body>
</html>
<?php
	// 5. Close connection
if (isset($conn)) {
$conn -> close();
}
?>