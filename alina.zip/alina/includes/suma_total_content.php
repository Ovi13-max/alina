<?php require_once("functions/functions.php");?>
<?php echo suma_total_content_link_css();?>
<div id="suma_total_content">
<?php
echo "<p>Aceasta este suma totală de care ați vîndut astăzi !!!</p><br>";
echo "<p>";
$sql = "SELECT sum(pret) FROM vinzari";
$result = mysqli_query($conn, $sql);
$num_results = mysqli_num_rows($result);
$row = mysqli_fetch_assoc($result);
echo 'Suma totală este : ' . '  ' . '<span>' . $row['sum(pret)'] . '</span>';
echo "</p>";
?>
</div>