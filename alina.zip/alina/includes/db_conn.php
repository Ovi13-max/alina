<?php require_once("constants.php");?>

<?php
//1. create database connection
$conn = mysqli_connect(DB_SERVER,DB_USER,"",DB_NAME);

//2. select database to use
$result = mysqli_query($conn, "SELECT DATABASE()");
$row = mysqli_fetch_row($result);
?>