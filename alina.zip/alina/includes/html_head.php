<?php require_once("db_conn.php");?>
<?php require_once("functions/functions.php");?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Alina Work</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="description" content="Alina Work Vapes Seller" />
	<meta name="keywords" content="vinzari vape si tigari electronice" />
	<meta name="robots" content="index,follow" />
	<meta name="author" content="Ovidiu Bara">
	<link rel="shortcut icon" href="images/favicon.ico">
	<link rel="stylesheet" type="text/css" media="all" href="style/main_style.css" />
    <meta name="viewport" content="width=device-width, initial-scale=0.4">
</head>
<body onload="startTime()">