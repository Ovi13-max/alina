

<div id="bottom_head">
<table>
<tr>
<td id="bottom_left_head"></td>
<td id="bottom_center_head">
    <ul>
        <li><a href= "delete_db.php">Sterge baza de date !!!</a></li>
        <li class="space">
            <a href= "register&login/logout.php">Log Out</a>&nbsp;&nbsp;&nbsp;
            <a href="register&login/reset-password.php">Resetează Parola</a>
        </li>
    </ul>
</td>
<td id="bottom_right_head"></td>
</tr>
</table>
</div>